﻿namespace WEB.MVCUI.Areas.Admin.Models.Dtos
{
    public class ShipperAddDto
    {
        public string ShipperName { get; set; }
        public string Phone { get; set; }
    }
}
