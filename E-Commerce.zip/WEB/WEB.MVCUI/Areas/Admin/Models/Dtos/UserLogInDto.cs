﻿namespace WEB.MVCUI.Areas.Admin.Models.Dtos
{
    public class UserLogInDto
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
