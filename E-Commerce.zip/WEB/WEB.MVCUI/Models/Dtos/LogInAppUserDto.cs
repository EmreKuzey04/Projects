﻿namespace WEB.MVCUI.Models.Dtos
{
    public class LogInAppUserDto
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
