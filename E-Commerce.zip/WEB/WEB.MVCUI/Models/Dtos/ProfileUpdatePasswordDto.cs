﻿namespace WEB.MVCUI.Models.Dtos
{
    public class ProfileUpdatePasswordDto
    {
            public string Password { get; set; }
            public string NewPassword { get; set; }
            public string ReNewPassword { get; set; }
        
    }
}
